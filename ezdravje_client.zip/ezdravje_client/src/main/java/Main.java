import si.um.feri.jee.sample.jsf.remote.DodajZdravnika;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

public class Main {
    public static void main(String [] args) throws NamingException {
     System.out.println("Client");
        Properties props = new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
        props.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        InitialContext ctx = new InitialContext(props);
        DodajZdravnika dodaj = (DodajZdravnika) ctx.lookup("/sampleProject/DodajZdravnikaClass!si.um.feri.jee.sample.jsf.remote.DodajZdravnika");
        dodaj.posljiInDodaj("pacient@gmail.com","zdravnikdve@gmail.com");
    }
}
