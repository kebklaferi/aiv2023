package si.um.feri.jee.sample.jsf.remote;


import javax.naming.NamingException;
import java.io.Serializable;

public interface DodajZdravnika extends Serializable {

    void posljiInDodaj(String pacMail, String zdrMail) throws NamingException;

}
