package si.um.feri.aiv.client.jms;

import si.um.feri.aiv.client.jms.InitialContextFactory;

import javax.jms.*;
import javax.naming.InitialContext;
import java.util.Scanner;

public class Posiljatelj {

    InitialContext ctx;
    QueueConnectionFactory factory;
    Queue queue;
    QueueConnection cnn;
    QueueSession session;
    QueueSender sender;

    Posiljatelj() throws Exception {
        ctx = InitialContextFactory.getInitialContext();
        factory = (QueueConnectionFactory) ctx.lookup("jms/RemoteConnectionFactory");
        queue = (Queue) ctx.lookup("jms/queue/test");
        cnn = factory.createQueueConnection();
        session = cnn.createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
        sender = session.createSender(queue);
    }
    public static void main(String[] args) throws Exception {
        Posiljatelj posiljatelj = new Posiljatelj();
        MapMessage message = posiljatelj.session.createMapMessage();
        Scanner scan = new Scanner(System.in);
        System.out.println("Vpisi zdravnikov mail: ");
        message.setString("1", scan.nextLine());
        System.out.println("Vpisi pacientov mail: ");
        message.setString("2", scan.nextLine());

        posiljatelj.sender.send(message);

		/*
		//sporocilo, ki ni trajno
		Message m=session.createTextMessage("NETRAJNO SPOROCILO");
		sender.send(m,DeliveryMode.NON_PERSISTENT,3,2000);

		//sporocilo, ki je trajno
		m=session.createTextMessage("TRAJNO SPOROCILO");
		sender.send(m,DeliveryMode.PERSISTENT,3,10000);

		 */

        posiljatelj.session.close();

    }
}
